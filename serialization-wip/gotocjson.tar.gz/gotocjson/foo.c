#include <stdio.h>

#include "transit.h"

extern const char * const foo_UnitEnum_String[];  // index by UnitEnum value, get associated string value back
typedef enum foo_UnitEnum foo_UnitEnum;

typedef int *int_Ptr;

int_Ptr int_ptr;

enum foo_UnitEnum {
    foo_NoUnits,
    foo_UnitCounter,
    foo_PercentCPU,
};

foo_UnitEnum units;

const char * const foo_UnitEnum_String[] = {
    "",            // no units specified
    "1",           // unspecified-unit counter 
    "%{cpu}",      // percent CPU, as in load measurements
};

typedef struct {
    int abc;
} foo;

typedef struct {
    foo foo;
} bar;

int main () {
    foo foo;
    bar bar;
    foo.abc = 1;
    bar.foo.abc = 2;
    printf ("foo.abc = %d; bar.foo.abc = %d\n", foo.abc, bar.foo.abc);
    return 23;
}
